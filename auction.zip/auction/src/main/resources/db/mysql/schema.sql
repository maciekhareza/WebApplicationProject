DROP TABLE IF EXISTS item_categories;
DROP TABLE IF EXISTS items;
DROP TABLE IF EXISTS categories;

CREATE TABLE auctions (
                     id           INTEGER AUTO_INCREMENT PRIMARY KEY,
                     name         VARCHAR(30),
                     price        NUMERIC(10, 2),
                     description  VARCHAR(255)
);
CREATE INDEX auctions_name ON auctions (name);

CREATE TABLE statuses (
                          id   INTEGER AUTO_INCREMENT PRIMARY KEY,
                          name VARCHAR(80)
);
CREATE INDEX statuses_name ON statuses (name);

CREATE TABLE auction_statuses (
                               auction_id       INTEGER NOT NULL,
                               status_id   INTEGER NOT NULL,
                               FOREIGN KEY (auction_id) REFERENCES auctions (id),
                               FOREIGN KEY (status_id) REFERENCES statuses (id)
);

