/*
 * Copyright 2012-2019 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springframework.hareza.allegrov2.auction;

import java.util.List;
import java.util.Map;

import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
class AuctionController {

	private static final String VIEWS_AUCTION_CREATE_OR_UPDATE_FORM = "auctions/createOrUpdateAuctionForm";
	private final AuctionRepository auctionRepository;

	public AuctionController(AuctionRepository clinicService) {
		this.auctionRepository = clinicService;
	}

	@GetMapping("/auctions.html")
	public String showAuctionList(@RequestParam(defaultValue = "1") int page, Model model) {
		// Here we are returning an object of type 'Auctions' rather than a collection of Auction
		// objects so it is simpler for Object-Xml mapping
		Auctions auctions = new Auctions();
		Page<Auction> paginated = findPaginated(page);
		auctions.getAuctionList().addAll(paginated.toList());
		return addPaginationModel(page, paginated, model);

	}

	private String addPaginationModel(int page, Page<Auction> paginated, Model model) {
		List<Auction> listAuctions = paginated.getContent();
		model.addAttribute("currentPage", page);
		model.addAttribute("totalPages", paginated.getTotalPages());
		model.addAttribute("totalAuctions", paginated.getTotalElements());
		model.addAttribute("listAuctions", listAuctions);
		return "auctions/auctionList";
	}

	private Page<Auction> findPaginated(int page) {
		int pageSize = 25;
		Pageable pageable = PageRequest.of(page - 1, pageSize);
		return auctionRepository.findAll(pageable);
	}

	@GetMapping({ "/auctions" })
	public @ResponseBody Auctions showResourcesAuctionList() {
		// Here we are returning an object of type 'Auctions' rather than a collection of Auction
		// objects so it is simpler for JSon/Object mapping
		Auctions auctions = new Auctions();
		auctions.getAuctionList().addAll(this.auctionRepository.findAll());
		return auctions;
	}

	@GetMapping("/auctions/new")
	public String initCreationForm(Map<String, Object> model) {
		Auction auction = new Auction();
		model.put("auction", auction);
		return VIEWS_AUCTION_CREATE_OR_UPDATE_FORM;
	}


	@PostMapping("/auctions/new")
	public String processCreationForm(@Valid Auction auction, BindingResult result) {
		if (result.hasErrors()) {
			return VIEWS_AUCTION_CREATE_OR_UPDATE_FORM;
		}

		this.auctionRepository.save(auction);
		return "redirect:/auctions.html";
	}


	@GetMapping("/auctions/{auctionId}/delete")
	public String processDeleteForm(@PathVariable("auctionId") int auctionId) {
		Auction auction = this.auctionRepository.findById(auctionId);
		if (auction != null) {
			this.auctionRepository.delete(auction);
		}
		return "redirect:/auctions.html";
	}


	@GetMapping("/auctions/{auctionId}/edit")
	public String initUpdateForm(@PathVariable("auctionId") int auctionId, Model model) {
		Auction auction = this.auctionRepository.findById(auctionId);
		model.addAttribute(auction);
		return VIEWS_AUCTION_CREATE_OR_UPDATE_FORM;
	}


	@PostMapping("/auctions/{auctionId}/edit")
	public String processUpdateForm(@Valid Auction auction, BindingResult result, @PathVariable("auctionId") int auctionId) {
		if (result.hasErrors()) {
			return VIEWS_AUCTION_CREATE_OR_UPDATE_FORM;
		}
		else {
			auction.setId(auctionId);
			this.auctionRepository.save(auction);
			return "redirect:/auctions.html";
		}
	}

	@GetMapping("/auctions/{auctionId}/status/{newStatus}")
	public String changeStatus(@PathVariable("auctionId") int auctionId, @PathVariable("newStatus") int newStatus ) {
		Auction auction = this.auctionRepository.findById(auctionId);
		Status status = new Status();
		status.setId(newStatus);
		auction.setStatus(status);
		this.auctionRepository.save(auction);
		return "redirect:/auctions.html";
	}

}
