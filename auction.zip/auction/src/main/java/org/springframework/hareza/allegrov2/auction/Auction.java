/*
 * Copyright 2012-2019 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springframework.hareza.allegrov2.auction;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import org.springframework.beans.support.MutableSortDefinition;
import org.springframework.beans.support.PropertyComparator;
import org.springframework.hareza.allegrov2.model.NamedEntity;

import jakarta.xml.bind.annotation.XmlElement;

@Entity
@Table(name = "auctions")
public class Auction extends NamedEntity {

	@Column(name = "price")
	@NotEmpty
	private String price;

	@Column(name = "description")
	@NotEmpty
	private String description;

	public String getPrice() {
		return this.price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setStatus(Status status) {
		getStatusesInternal().clear();
		getStatusesInternal().add(status);
	}

	public Status getStatus() {
		return getStatuses().get(0);
	}

	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "auction_statuses", joinColumns = @JoinColumn(name = "auction_id"),
			inverseJoinColumns = @JoinColumn(name = "status_id"))
	private Set<Status> statuses;

	protected Set<Status> getStatusesInternal() {
		if (this.statuses == null) {
			this.statuses = new HashSet<>();
		}
		return this.statuses;
	}

	protected void setStatusesInternal(Set<Status> statuses) {
		this.statuses = statuses;
	}

	@XmlElement
	public List<Status> getStatuses() {
		List<Status> sortedSpecs = new ArrayList<>(getStatusesInternal());
		PropertyComparator.sort(sortedSpecs, new MutableSortDefinition("name", true, true));
		return Collections.unmodifiableList(sortedSpecs);
	}

	public int getNrOfStatuses() {
		return getStatusesInternal().size();
	}

	public boolean isNew() {
		return (this.getId() == null);
	}

}
